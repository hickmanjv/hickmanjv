//
//  ViewController.swift
//  Colors
//
//  Created by Joshua Hickman on 7/1/20.
//  Copyright © 2020 Joshua Hickman. All rights reserved.
//

import UIKit

class ColorsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    // array of colors for the table
    let colors = ["red", "orange", "yellow", "green", "blue",
                  "purple", "brown"]
    
    // corresponding array that matches the sequence of the colors array
    let useableColors = [UIColor.red, UIColor.orange, UIColor.yellow, UIColor.green, UIColor.blue, UIColor.purple, UIColor.brown]
    
    
    /* Wanted to manually code the datasource and delegate to have some more practice with the syntax of the language */
    @IBOutlet weak var colorsTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        // assigning this view controller as the datasource and delegate
        colorsTableView.dataSource = self
        colorsTableView.delegate = self
    }
    
    // only 1 section of the table
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    /* function to get number of cells needed for the table based on
       the colors array */
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    
        return colors.count
    }

    // Function that sets up how the cell will look when displayed
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "colorCell", for: indexPath)
        
        // setting the cell text with colors array
        cell.textLabel?.text = colors[indexPath.row]

        // setting the cell background color with useableColors array
        cell.backgroundColor = useableColors[indexPath.row]
        
        return cell
    }

}

